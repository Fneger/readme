# Filecoin封装流程详解

## 封装流程总览
![Distributed Miner](../images/mining-process.png)

## 调度总览
![Distributed Miner](../images/schedule-amd7542-32.png)